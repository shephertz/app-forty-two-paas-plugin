package com.shephertz.app42.paas.sdk.plugin.grails.cloudapi

import com.shephertz.app42.paas.sdk.java.ServiceAPI
import com.shephertz.app42.paas.sdk.java.session.Session
import com.shephertz.app42.paas.sdk.java.session.SessionService
import com.shephertz.app42.paas.sdk.java.App42Exception
import com.shephertz.app42.paas.sdk.java.App42Response


class SessionApp42Service {

    static transactional = true
    static scope = "request"
    
    def apiService

    Session getSession(String uName) throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        SessionService sessionService = serviceAPI.buildSessionManager()
        Session session = sessionService.getSession(uName)
        return session

    }
    
    Session getSession(String uName, boolean isCreate) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        SessionService sessionService = serviceAPI.buildSessionManager()
        Session session = sessionService.getSession(uName, isCreate)
        return session
    }
    
    
    App42Response invalidate(String sessionId) throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        SessionService sessionService = serviceAPI.buildSessionManager()
        return sessionService.invalidate(sessionId)
    }
    
    Session setAttribute(String sessionId, String attributeName,String attributeValue) throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        SessionService sessionService = serviceAPI.buildSessionManager()
        Session session = sessionService.setAttribute(sessionId, attributeName, attributeValue)
        return session
    }
    
    Session getAttribute(String sessionId, String attributeName)throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        SessionService sessionService = serviceAPI.buildSessionManager()
        Session session = sessionService.getAttribute(sessionId, attributeName)
        return session
    }
    
    Session getAllAttributes(String sessionId) throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        SessionService sessionService = serviceAPI.buildSessionManager()
        Session session = sessionService.getAllAttributes(sessionId)
        return session
    }
    
    App42Response removeAttribute(String sessionId, String attributeName)throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        SessionService sessionService = serviceAPI.buildSessionManager()
        return sessionService.removeAttribute(sessionId, attributeName)
    }
    
    App42Response removeAllAttributes(String sessionId) throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        SessionService sessionService = serviceAPI.buildSessionManager()
        return sessionService.removeAllAttributes(sessionId)
    }
    
    
}
