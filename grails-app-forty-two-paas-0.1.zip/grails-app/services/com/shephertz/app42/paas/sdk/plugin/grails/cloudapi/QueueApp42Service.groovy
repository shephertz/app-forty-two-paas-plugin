package com.shephertz.app42.paas.sdk.plugin.grails.cloudapi

import com.shephertz.app42.paas.sdk.java.ServiceAPI
import com.shephertz.app42.paas.sdk.java.message.Queue
import com.shephertz.app42.paas.sdk.java.message.QueueService
import com.shephertz.app42.paas.sdk.java.App42Exception
import com.shephertz.app42.paas.sdk.java.App42Response

class QueueApp42Service {

    static transactional = true
    static scope = "request"
    
    def apiService
    

    Queue receiveMessage(String queueName, long receiveTimeOut) throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        QueueService queueService = serviceAPI.buildQueueService()
        Queue queue = queueService.receiveMessage(queueName, receiveTimeOut)
        return queue
    }
    
    Queue receiveMessageByCorrelationId(String queueName, long receiveTimeOut, String correlationId) throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        QueueService queueService = serviceAPI.buildQueueService()
        Queue queue = queueService.receiveMessageByCorrelationId(queueName, receiveTimeOut, correlationId)
        return queue
    }
    
    App42Response removeMessage(String queueName, String messageId) throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        QueueService queueService = serviceAPI.buildQueueService()
        return queueService.removeMessage(queueName, messageId)
    }
    
    Queue sendMessage(String queueName, String msg, long exp) throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        QueueService queueService = serviceAPI.buildQueueService()
        Queue queue = queueService.sendMessage(queueName, msg, exp)
        return queue
    }
    
    Queue createPullQueue(String queueName, String queueDescription) throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        QueueService queueService = serviceAPI.buildQueueService()
        Queue queue = queueService.createPullQueue(queueName, queueDescription)
        return queue
    }
    
    App42Response deletePullQueue(String queueName) throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        QueueService queueService = serviceAPI.buildQueueService()
        return queueService.deletePullQueue(queueName)
    }
    
    Queue getMessages(String queueName, long receiveTimeOut) throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        QueueService queueService = serviceAPI.buildQueueService()
        Queue queue = queueService.getMessages(queueName, receiveTimeOut)
        return queue
    }
    
    Queue pendingMessages(String queueName) throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        QueueService queueService = serviceAPI.buildQueueService()
        Queue queue = queueService.pendingMessages(queueName)
        return queue
    }
    
    App42Response purgePullQueue(String queueName) throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        QueueService queueService = serviceAPI.buildQueueService()
        App42Response response = queueService.purgePullQueue(queueName)
        return response
    }
    
}
