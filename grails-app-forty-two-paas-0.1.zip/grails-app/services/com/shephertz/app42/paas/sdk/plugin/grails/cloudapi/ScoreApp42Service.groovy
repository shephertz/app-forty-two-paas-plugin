package com.shephertz.app42.paas.sdk.plugin.grails.cloudapi

import com.shephertz.app42.paas.sdk.java.ServiceAPI
import com.shephertz.app42.paas.sdk.java.game.Game
import com.shephertz.app42.paas.sdk.java.game.ScoreService
import com.shephertz.app42.paas.sdk.java.App42Exception
import com.shephertz.app42.paas.sdk.java.App42Response

class ScoreApp42Service {

    static transactional = true
    static scope = "request"
    
    def apiService
    
    Game addScore(String gameName, String gameUserName,double gameScore) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        ScoreService scoreService = serviceAPI.buildScoreService()
        Game game = scoreService.addScore(gameName, gameUserName, gameScore)
        return game
    }
    
    Game deductScore(String gameName, String gameUserName, double gameScore) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        ScoreService scoreService = serviceAPI.buildScoreService()
        Game game = scoreService.deductScore(gameName, gameUserName, gameScore)
        return game
    }
    
}
