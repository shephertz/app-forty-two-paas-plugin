package com.shephertz.app42.paas.sdk.plugin.grails.cloudapi

import com.shephertz.app42.paas.sdk.java.ServiceAPI
import com.shephertz.app42.paas.sdk.java.appTab.License
import com.shephertz.app42.paas.sdk.java.appTab.LicenseService

import com.shephertz.app42.paas.sdk.java.App42Exception
import com.shephertz.app42.paas.sdk.java.App42Response

class LicenseApp42Service {

   static transactional = true
    static scope = "request"
    
    def apiService
    
    License createLicense(String licenseName, BigDecimal licensePrice,String licenseCurrency, String licenseDescription) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        LicenseService licenseService = serviceAPI.buildLicenseService()
        License license = licenseService.createLicense(licenseName, licensePrice,licenseCurrency,licenseDescription)
        return license 
    }
    License issueLicense(String userName,String licenseName) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        LicenseService licenseService = serviceAPI.buildLicenseService()
        License license = licenseService.issueLicense(userName, licenseName)
        return license 
    }
    License getLicense(String licenseName) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        LicenseService licenseService = serviceAPI.buildLicenseService()
        License license = licenseService.getLicense(licenseName)
        return license 
    }
    ArrayList<License> getAllLicenses() throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        LicenseService licenseService = serviceAPI.buildLicenseService()
        ArrayList<License> licenses = licenseService.getAllLicenses()
        return licenses 
    }
    ArrayList<License> getIssuedLicenses(String userName,String licenseName) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        LicenseService licenseService = serviceAPI.buildLicenseService()
        ArrayList<License> licenses = licenseService.getIssuedLicenses(userName, licenseName)
        return licenses 
    }
    License isValid(String userName, String licenseName, String key) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        LicenseService licenseService = serviceAPI.buildLicenseService()
        License license = licenseService.isValid(userName, licenseName,key)
        return license 
    }
    License revokeLicense(String userName, String licenseName, String key) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        LicenseService licenseService = serviceAPI.buildLicenseService()
        License license = licenseService.revokeLicense(userName, licenseName,key)
        return license 
    }
}
