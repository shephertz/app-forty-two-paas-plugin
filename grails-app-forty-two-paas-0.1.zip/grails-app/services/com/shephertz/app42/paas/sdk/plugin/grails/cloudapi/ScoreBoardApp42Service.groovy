package com.shephertz.app42.paas.sdk.plugin.grails.cloudapi

import com.shephertz.app42.paas.sdk.java.ServiceAPI
import com.shephertz.app42.paas.sdk.java.game.Game
import com.shephertz.app42.paas.sdk.java.game.ScoreBoardService
import com.shephertz.app42.paas.sdk.java.App42Exception
import com.shephertz.app42.paas.sdk.java.App42Response

class ScoreBoardApp42Service {

    static transactional = true
    static scope = "request"
    
    def apiService
    
    
    Game saveUserScore(String gameName, String gameUserName,double gameScore) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        ScoreBoardService scoreBoardService = serviceAPI.buildScoreBoardService()
        Game game = scoreBoardService.saveUserScore(gameName, gameUserName, gameScore)
        return game
    }
    
    Game getScoresByUser(String gameName, String userName) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        ScoreBoardService scoreBoardService = serviceAPI.buildScoreBoardService()
        Game game = scoreBoardService.getScoresByUser(gameName, userName)
        return game
    }
    
    Game getHighestScoreByUser(String gameName, String userName) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        ScoreBoardService scoreBoardService = serviceAPI.buildScoreBoardService()
        Game game = scoreBoardService.getHighestScoreByUser(gameName, userName)
        return game
    }
    
    Game getLowestScoreByUser(String gameName, String userName) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        ScoreBoardService scoreBoardService = serviceAPI.buildScoreBoardService()
        Game game = scoreBoardService.getLowestScoreByUser(gameName, userName)
        return game
    }
    
    Game getAverageScoreByUser(String gameName, String userName) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        ScoreBoardService scoreBoardService = serviceAPI.buildScoreBoardService()
        Game game = scoreBoardService.getAverageScoreByUser(gameName, userName)
        return game
    }
    
    Game getTopRankings(String gameName) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        ScoreBoardService scoreBoardService = serviceAPI.buildScoreBoardService()
        Game game = scoreBoardService.getTopRankings(gameName)
        return game
    }

    Game getTopNRankings(String gameName, int max) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        ScoreBoardService scoreBoardService = serviceAPI.buildScoreBoardService()
        Game game = scoreBoardService.getTopNRankings(gameName, max)
        return game
    }

    Game getUserRanking(String gameName, String userName) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        ScoreBoardService scoreBoardService = serviceAPI.buildScoreBoardService()
        Game game = scoreBoardService.getUserRanking(gameName, userName)
        return game
    }
}
