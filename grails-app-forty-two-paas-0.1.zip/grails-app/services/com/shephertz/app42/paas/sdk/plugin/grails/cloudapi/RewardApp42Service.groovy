package com.shephertz.app42.paas.sdk.plugin.grails.cloudapi

import com.shephertz.app42.paas.sdk.java.ServiceAPI
import com.shephertz.app42.paas.sdk.java.game.Reward
import com.shephertz.app42.paas.sdk.java.game.RewardService
import com.shephertz.app42.paas.sdk.java.App42Exception
import com.shephertz.app42.paas.sdk.java.App42Response

class RewardApp42Service {

    static transactional = true
    static scope = "request"
    
    def apiService
    
    Reward createReward(String rewardName, String rewardDescription) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        RewardService rewardService = serviceAPI.buildRewardService()
        Reward reward = rewardService.createReward(rewardName, rewardDescription)
        return reward
    }
    
    App42Response getAllRewardsCount() throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        RewardService rewardService = serviceAPI.buildRewardService()
        return rewardService.getAllRewardsCount()
    }
    
    ArrayList<Reward> getAllRewards() throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        RewardService rewardService = serviceAPI.buildRewardService()
        ArrayList<Reward> rewardList = rewardService.getAllRewards()
        return rewardList
    }
    
    ArrayList<Reward> getAllRewards(int max, int offset) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        RewardService rewardService = serviceAPI.buildRewardService()
        ArrayList<Reward> rewardList = rewardService.getAllRewards(max, offset)
        return rewardList
    }
    
    Reward getRewardByName(String rewardName) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        RewardService rewardService = serviceAPI.buildRewardService()
        Reward reward = rewardService.getRewardByName(rewardName)
        return reward
    }
    
    Reward earnRewards(String gameName, String gameUserName, String rewardName, double rewardPoints) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        RewardService rewardService = serviceAPI.buildRewardService()
        Reward reward = rewardService.earnRewards(gameName, gameUserName, rewardName, rewardPoints)
        return reward
    }
    
    Reward redeemRewards(String gameName, String gameUserName,String rewardName, double rewardPoints) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        RewardService rewardService = serviceAPI.buildRewardService()
        Reward reward = rewardService.redeemRewards(gameName, gameUserName, rewardName, rewardPoints)
        return reward
    }

    Reward getGameRewardPointsForUser(String gameName, String userName) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        RewardService rewardService = serviceAPI.buildRewardService()
        Reward reward = rewardService.getGameRewardPointsForUser(gameName, userName)
        return reward
    }
    
}
