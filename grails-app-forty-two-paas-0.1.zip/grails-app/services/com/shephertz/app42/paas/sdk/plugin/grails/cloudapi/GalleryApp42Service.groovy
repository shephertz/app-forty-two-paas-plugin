package com.shephertz.app42.paas.sdk.plugin.grails.cloudapi

import com.shephertz.app42.paas.sdk.java.ServiceAPI
import com.shephertz.app42.paas.sdk.java.gallery.Album
import com.shephertz.app42.paas.sdk.java.gallery.AlbumService
import com.shephertz.app42.paas.sdk.java.App42Exception
import com.shephertz.app42.paas.sdk.java.App42Response

class GalleryApp42Service {

    static transactional = true
    static scope = "request"
    
    def apiService
    

    Album createAlbum(String userName, String albumName, String albumDescription) throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        AlbumService albumService = serviceAPI.buildAlbumService()
        Album album = albumService.createAlbum(userName, albumName, albumDescription)
        return album
    }
    
    ArrayList<Album> getAlbums(String userName) throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        AlbumService albumService = serviceAPI.buildAlbumService()
        ArrayList<Album> albumList = albumService.getAlbums(userName);
        return albumList
    }
    ArrayList<Album> getAlbums(String userName,int max,int offset) throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        AlbumService albumService = serviceAPI.buildAlbumService()
        ArrayList<Album> albumList = albumService.getAlbums(userName,max,offset);
        return albumList
    }
    Album getAlbumByName(String userName, String albumName)throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        AlbumService albumService = serviceAPI.buildAlbumService()
        Album album = albumService.getAlbumByName(userName,albumName)
        return album
    }
    
    App42Response removeAlbum(String userName, String albumName)throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        AlbumService albumService = serviceAPI.buildAlbumService()
        return albumService.removeAlbum(userName, albumName)
    }
    
    App42Response getAlbumsCount(String userName) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        AlbumService albumService = serviceAPI.buildAlbumService()
        return albumService.getAlbumsCount(userName)
    }
    
    
    
    
}
