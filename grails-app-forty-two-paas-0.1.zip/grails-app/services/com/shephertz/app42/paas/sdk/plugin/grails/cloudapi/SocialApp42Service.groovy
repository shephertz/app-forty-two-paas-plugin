package com.shephertz.app42.paas.sdk.plugin.grails.cloudapi

import com.shephertz.app42.paas.sdk.java.ServiceAPI
import com.shephertz.app42.paas.sdk.java.social.Social
import com.shephertz.app42.paas.sdk.java.social.SocialService
import com.shephertz.app42.paas.sdk.java.App42Exception
import com.shephertz.app42.paas.sdk.java.App42Response

class SocialApp42Service {

    static transactional = true
    static scope = "request"
    
    def apiService
   
    Social linkUserFacebookAccount(String userName, String appId, String appSecret, String accessToken) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        SocialService socialService = serviceAPI.buildSocialService()
        Social social = socialService.linkUserFacebookAccount(userName, appId, appSecret, accessToken)
        return social
    }
    
    Social linkUserFacebookAccount(String userName, String accessToken) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        SocialService socialService = serviceAPI.buildSocialService()
        Social social = socialService.linkUserFacebookAccount(userName, accessToken)
        return social
    }
    
    Social updateFacebookStatus(String userName, String status) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        SocialService socialService = serviceAPI.buildSocialService()
        Social social = socialService.updateFacebookStatus(userName, status)
        return social
    }
    
    Social linkUserTwitterAccount(String userName, String consumerKey, String consumerSecret, String accessToken, String accessTokenSecret) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        SocialService socialService = serviceAPI.buildSocialService()
        Social social = socialService.linkUserTwitterAccount(userName, consumerKey, consumerSecret, accessToken, accessTokenSecret)
        return social
    }
     Social linkUserTwitterAccount(String userName, String accessToken, String accessTokenSecret) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        SocialService socialService = serviceAPI.buildSocialService()
        Social social = socialService.linkUserTwitterAccount(userName, accessToken, accessTokenSecret)
        return social
    }

    Social updateTwitterStatus(String userName, String status) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        SocialService socialService = serviceAPI.buildSocialService()
        Social social = socialService.updateTwitterStatus(userName, status)
        return social
    }
    
    Social linkUserLinkedInAccount(String userName, String apiKey, String secretKey, String accessToken, String accessTokenSecret) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        SocialService socialService = serviceAPI.buildSocialService()
        Social social = socialService.linkUserLinkedInAccount(userName, apiKey, secretKey, accessToken, accessTokenSecret)
        return social
    }
     Social linkUserLinkedInAccount(String userName, String accessToken, String accessTokenSecret) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        SocialService socialService = serviceAPI.buildSocialService()
        Social social = socialService.linkUserLinkedInAccount(userName, accessToken, accessTokenSecret)
        return social
    }

    Social updateLinkedInStatus(String userName, String status) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        SocialService socialService = serviceAPI.buildSocialService()
        Social social = socialService.updateLinkedInStatus(userName, status)
        return social
    }
    
    Social updateSocialStatusForAll(String userName, String status) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        SocialService socialService = serviceAPI.buildSocialService()
        Social social = socialService.updateSocialStatusForAll(userName, status)
        return social
    }
    
    
    
    
    
    
}
