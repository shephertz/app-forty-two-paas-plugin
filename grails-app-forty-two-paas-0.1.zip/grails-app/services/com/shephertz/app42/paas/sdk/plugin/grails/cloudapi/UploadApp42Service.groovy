package com.shephertz.app42.paas.sdk.plugin.grails.cloudapi

import com.shephertz.app42.paas.sdk.java.ServiceAPI
import com.shephertz.app42.paas.sdk.java.upload.Upload
import com.shephertz.app42.paas.sdk.java.upload.UploadFileType
import com.shephertz.app42.paas.sdk.java.upload.UploadService
import com.shephertz.app42.paas.sdk.java.App42Exception
import com.shephertz.app42.paas.sdk.java.App42Response
class UploadApp42Service {

    static transactional = true
    static scope = "request"
    
    def apiService
    
    Upload uploadFile(String name, String filePath, UploadFileType fileType, String description) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UploadService uploadService = serviceAPI.buildUploadService()
        Upload upload = uploadService.uploadFile(name, filePath, fileType, description)
        return upload
    }
    
    Upload uploadFile(String name, InputStream inputStream,UploadFileType fileType, String description) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UploadService uploadService = serviceAPI.buildUploadService()
        Upload upload = uploadService.uploadFile(name, inputStream, fileType, description)
        return upload
    }
    
    Upload getAllFiles() throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UploadService uploadService = serviceAPI.buildUploadService()
        Upload upload = uploadService.getAllFiles()
    }
    
    Upload getFileByName(String name) throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UploadService uploadService = serviceAPI.buildUploadService()
        Upload upload = uploadService.getFileByName(name)
    }
    
    Upload getFilesByType(UploadFileType uploadFileType) throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UploadService uploadService = serviceAPI.buildUploadService()
        Upload upload = uploadService.getFilesByType(uploadFileType)
    }
    
    App42Response removeFileByName(String name) throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UploadService uploadService = serviceAPI.buildUploadService()
        App42Response response = uploadService.removeFileByName(name)
        return response
    }
    
    App42Response removeAllFiles() throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UploadService uploadService = serviceAPI.buildUploadService()
        App42Response response = uploadService.removeAllFiles()
        return response
    }
    
    Upload uploadFileForUser(String name, String userName, String filePath, UploadFileType fileType, String description) throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UploadService uploadService = serviceAPI.buildUploadService()
        Upload upload = uploadService.uploadFileForUser(name,userName,filePath,fileType,description)
    }
    
    Upload uploadFileForUser(String name, String userName,InputStream inputStream, UploadFileType fileType, String description) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UploadService uploadService = serviceAPI.buildUploadService()
        Upload upload = uploadService.uploadFileForUser(name,userName,inputStream,fileType,description)
    }
    
    
    Upload getFileByUser(String name, String userName) throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UploadService uploadService = serviceAPI.buildUploadService()
        Upload upload = uploadService.getFileByUser(name, userName)
    }
    
    Upload getAllFilesByUser(String userName) throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UploadService uploadService = serviceAPI.buildUploadService()
        Upload upload = uploadService.getAllFilesByUser(userName)
    }
    
    App42Response removeFileByUser(String name, String userName) throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UploadService uploadService = serviceAPI.buildUploadService()
        App42Response response = uploadService.removeFileByUser(name, userName)
        return response
    }
    
    App42Response removeAllFilesByUser(String userName) throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UploadService uploadService = serviceAPI.buildUploadService()
        App42Response response = uploadService.removeAllFilesByUser(userName)
        return response
    }
    
    App42Response getAllFilesCount() throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UploadService uploadService = serviceAPI.buildUploadService()
        App42Response response = uploadService.getAllFilesCount()
        return response
    }
    
    App42Response getAllFilesCountByUser(String userName) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UploadService uploadService = serviceAPI.buildUploadService()
        App42Response response = uploadService.getAllFilesCountByUser(userName)
        return response
    }
    
    Upload getAllFiles(int max, int offset){
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UploadService uploadService = serviceAPI.buildUploadService()
        Upload upload = uploadService.getAllFiles(max, offset)
    }
    
    Upload getAllFilesByUser(String userName,int max, int offset){
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UploadService uploadService = serviceAPI.buildUploadService()
        Upload upload = uploadService.getAllFilesByUser(userName, max, offset)
    }
			
    App42Response getFilesCountByType(UploadFileType uploadFileType){
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UploadService uploadService = serviceAPI.buildUploadService()
        App42Response response = uploadService.getFilesCountByType(uploadFileType)
        return response
    }
	
    Upload getFilesByType(UploadFileType uploadFileType,int max, int offset) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UploadService uploadService = serviceAPI.buildUploadService()
        Upload upload = uploadService.getFilesByType(uploadFileType, max, offset)
    }
    
}
