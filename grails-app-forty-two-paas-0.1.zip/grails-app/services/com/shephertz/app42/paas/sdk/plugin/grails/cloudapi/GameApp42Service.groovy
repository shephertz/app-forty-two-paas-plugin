package com.shephertz.app42.paas.sdk.plugin.grails.cloudapi

import com.shephertz.app42.paas.sdk.java.ServiceAPI
import com.shephertz.app42.paas.sdk.java.game.Game
import com.shephertz.app42.paas.sdk.java.game.Reward
import com.shephertz.app42.paas.sdk.java.game.GameService
import com.shephertz.app42.paas.sdk.java.game.ScoreService
import com.shephertz.app42.paas.sdk.java.game.ScoreBoardService
import com.shephertz.app42.paas.sdk.java.game.RewardService
import com.shephertz.app42.paas.sdk.java.App42Exception
import com.shephertz.app42.paas.sdk.java.App42Response

class GameApp42Service {

    static transactional = true
    static scope = "request"
    
    def apiService
    
    Game createGame(String gameName, String gameDescription) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        GameService gameService = serviceAPI.buildGameService()
        Game game = gameService.createGame(gameName, gameDescription)
        return game
    }
    
    App42Response getAllGamesCount() throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        GameService gameService = serviceAPI.buildGameService()
        return gameService.getAllGamesCount()
    }
    
    ArrayList<Game> getAllGames() throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        GameService gameService = serviceAPI.buildGameService()
        ArrayList<Game> gameList = gameService.getAllGames()
        return gameList
    }
    
    ArrayList<Game> getAllGames(int max, int offset) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        GameService gameService = serviceAPI.buildGameService()
        ArrayList<Game> gameList = gameService.getAllGames(max, offset)
        return gameList
    }
    
    Game getGameByName(String gameName) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        GameService gameService = serviceAPI.buildGameService()
        Game game = gameService.getGameByName(gameName)
        return game
    }
}
