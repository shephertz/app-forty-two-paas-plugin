package com.shephertz.app42.paas.sdk.plugin.grails.cloudapi

import com.shephertz.app42.paas.sdk.java.ServiceAPI
import com.shephertz.app42.paas.sdk.java.gallery.Album
import com.shephertz.app42.paas.sdk.java.gallery.PhotoService
import com.shephertz.app42.paas.sdk.java.App42Exception
import com.shephertz.app42.paas.sdk.java.App42Response

class PhotoApp42Service {

    static transactional = true
    static scope = "request"
    
    def apiService
   
    Album addPhoto(String userName, String albumName, String photoName, String photoDescription, String path) throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        PhotoService photoService = serviceAPI.buildPhotoService()
        Album album = photoService.addPhoto(userName,albumName,photoName,photoDescription,path)
        return album
    }
    
    Album addPhoto(String userName, String albumName, String photoName, String photoDescription, InputStream inputStream) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        PhotoService photoService = serviceAPI.buildPhotoService()
        Album album = photoService.addPhoto(userName, albumName, photoName, photoDescription, inputStream)
        return album
    }
    
    ArrayList<Album> getPhotos(String userName) throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        PhotoService photoService = serviceAPI.buildPhotoService()
        ArrayList<Album> albumList = photoService.getPhotos(userName)
        return albumList
    }
    
    Album getPhotosByAlbumName(String userName, String albumName) throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        PhotoService photoService = serviceAPI.buildPhotoService()
        Album album = photoService.getPhotosByAlbumName(userName,albumName)
        return album
    }
    Album getPhotosByAlbumName(String userName, String albumName,int max, int offset) throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        PhotoService photoService = serviceAPI.buildPhotoService()
        Album album = photoService.getPhotosByAlbumName(userName,albumName,max,offset)
        return album
    }
    Album getPhotosByAlbumAndPhotoName(String userName, String albumName, String photoName) throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        PhotoService photoService = serviceAPI.buildPhotoService()
        Album album = photoService.getPhotosByAlbumAndPhotoName(userName,albumName, photoName)
        return album
    }
    
    App42Response removePhoto(String userName, String albumName,String photoName) throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        PhotoService photoService = serviceAPI.buildPhotoService()
        App42Response response = photoService.removePhoto(userName, albumName, photoName)
        return response
    }
    
    Album addTagToPhoto(String userName, String albumName, String photoName, ArrayList<String> tagList) throws App42Exception {
	ServiceAPI serviceAPI = apiService.getServiceAPI()
        PhotoService photoService = serviceAPI.buildPhotoService()
        Album album = photoService.addTagToPhoto(userName,albumName, photoName, tagList)
        return album	
    }
    
    App42Response getPhotosCountByAlbumName(String userName, String albumName) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        PhotoService photoService = serviceAPI.buildPhotoService()
        App42Response response = photoService.getPhotosCountByAlbumName(userName, albumName)
        return response
    } 
        
    ArrayList<Album> getTaggedPhotos(String userName, String tag) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        PhotoService photoService = serviceAPI.buildPhotoService()
        ArrayList<Album> albumList = photoService.getTaggedPhotos(userName, tag)
        return albumList
    }
    
    
}
