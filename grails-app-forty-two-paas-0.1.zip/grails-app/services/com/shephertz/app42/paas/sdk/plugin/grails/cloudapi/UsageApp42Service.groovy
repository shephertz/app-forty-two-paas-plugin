package com.shephertz.app42.paas.sdk.plugin.grails.cloudapi

import com.shephertz.app42.paas.sdk.java.ServiceAPI
import com.shephertz.app42.paas.sdk.java.appTab.Usage
import com.shephertz.app42.paas.sdk.java.appTab.StorageUnit
import com.shephertz.app42.paas.sdk.java.appTab.Currency
import com.shephertz.app42.paas.sdk.java.appTab.UsageService
import com.shephertz.app42.paas.sdk.java.appTab.TimeUnit
import com.shephertz.app42.paas.sdk.java.appTab.BandwidthUnit

import com.shephertz.app42.paas.sdk.java.App42Exception
import com.shephertz.app42.paas.sdk.java.App42Response
class UsageApp42Service {

    static transactional = true
    static scope = "request"
    
    def apiService
    
    Usage createLevelCharge(String levelName, BigDecimal levelPrice,Currency levelCurrency, String levelDescription) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UsageService usageService = serviceAPI.buildUsageService()
        Usage usage = usageService.createLevelCharge(levelName, levelPrice,levelCurrency,levelDescription)
        return usage 
    }
    Usage getLevel(String levelName) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UsageService usageService = serviceAPI.buildUsageService()
        Usage usage = usageService.getLevel(levelName)
        return usage 
    }
    Usage removeLevel(String levelName) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UsageService usageService = serviceAPI.buildUsageService()
        Usage usage = usageService.removeLevel(levelName)
        return usage 
    }
    Usage createOneTimeCharge(String oneTimeName,BigDecimal oneTimePrice, Currency oneTimeCurrency,String oneTimeDescription) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UsageService usageService = serviceAPI.buildUsageService()
        Usage usage = usageService.createOneTimeCharge(oneTimeName, oneTimePrice,oneTimeCurrency,oneTimeDescription)
        return usage 
    }
    Usage getOneTime(String oneTimeName) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UsageService usageService = serviceAPI.buildUsageService()
        Usage usage = usageService.getOneTime(oneTimeName)
        return usage 
    }
    Usage removeOneTime(String oneTimeName) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UsageService usageService = serviceAPI.buildUsageService()
        Usage usage = usageService.removeOneTime(oneTimeName)
        return usage 
    }
    Usage createFeatureCharge(String featureName,BigDecimal featurePrice, Currency featureCurrency,String featureDescription) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UsageService usageService = serviceAPI.buildUsageService()
        Usage usage = usageService.createFeatureCharge(featureName, featurePrice,featureCurrency,featureDescription)
        return usage 
    }
    Usage getFeature(String featureName) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UsageService usageService = serviceAPI.buildUsageService()
        Usage usage = usageService.getFeature(featureName)
        return usage 
    }
    Usage removeFeature(String featureName) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UsageService usageService = serviceAPI.buildUsageService()
        Usage usage = usageService.removeFeature(featureName)
        return usage 
    }
    Usage createBandwidthCharge(String bandwidthName,BigDecimal bandwidthUsage, BandwidthUnit bandWidthUnit,BigDecimal bandwidthPrice, Currency bandwidthCurrency,String bandwidthDescription) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UsageService usageService = serviceAPI.buildUsageService()
        Usage usage = usageService.createBandwidthCharge(bandwidthName, bandwidthUsage,bandWidthUnit,bandwidthPrice,bandwidthCurrency,bandwidthDescription)
        return usage 
    }
    Usage getBandwidth(String bandwidthName) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UsageService usageService = serviceAPI.buildUsageService()
        Usage usage = usageService.getBandwidth(bandwidthName)
        return usage 
    }
    Usage removeBandwidth(String bandwidthName) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UsageService usageService = serviceAPI.buildUsageService()
        Usage usage = usageService.removeBandwidth(bandwidthName)
        return usage 
    }
    Usage createStorageCharge(String storageName,BigDecimal storageSpace, StorageUnit storageUnit,BigDecimal storagePrice, Currency storageCurrency,String storageDescription) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UsageService usageService = serviceAPI.buildUsageService()
        Usage usage = usageService.createStorageCharge(storageName, storageSpace,storageUnit,storagePrice,storageCurrency,storageDescription)
        return usage 
    }
    Usage getStorage(String storageName) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UsageService usageService = serviceAPI.buildUsageService()
        Usage usage = usageService.getStorage(storageName)
        return usage 
    }
    Usage removeStorage(String storageName) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UsageService usageService = serviceAPI.buildUsageService()
        Usage usage = usageService.removeStorage(storageName)
        return usage 
    }
    Usage createTimeCharge(String timeName, long timeUsage,TimeUnit timeUnit, BigDecimal timePrice, Currency timeCurrency,String timeDescription) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UsageService usageService = serviceAPI.buildUsageService()
        Usage usage = usageService.createTimeCharge(timeName,timeUsage,timeUnit,timePrice,timeCurrency,timeDescription)
        return usage 
    }
    Usage getTime(String timeName) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UsageService usageService = serviceAPI.buildUsageService()
        Usage usage = usageService.getTime(timeName)
        return usage 
    }
    Usage removeTime(String timeName) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UsageService usageService = serviceAPI.buildUsageService()
        Usage usage = usageService.removeTime(timeName)
        return usage 
    }
    Usage chargeLevel(String chargeUser, String levelName) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UsageService usageService = serviceAPI.buildUsageService()
        Usage usage = usageService.chargeLevel(chargeUser,levelName)
        return usage 
    }
    Usage chargeOneTime(String chargeUser, String oneTimeName) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UsageService usageService = serviceAPI.buildUsageService()
        Usage usage = usageService.chargeOneTime(chargeUser,oneTimeName)
        return usage 
    }
    Usage chargeFeature(String chargeUser, String featureName) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UsageService usageService = serviceAPI.buildUsageService()
        Usage usage = usageService.chargeFeature(chargeUser,featureName)
        return usage 
    }
    Usage chargeBandwidth(String chargeUser, String bandwidthName,BigDecimal bandwidth, BandwidthUnit bandWidthUnit) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UsageService usageService = serviceAPI.buildUsageService()
        Usage usage = usageService.chargeBandwidth(chargeUser,bandwidthName,bandwidth,bandWidthUnit)
        return usage 
    }
    Usage chargeStorage(String chargeUser, String storageName,BigDecimal storageSpace, StorageUnit storageUnit) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UsageService usageService = serviceAPI.buildUsageService()
        Usage usage = usageService.chargeStorage(chargeUser,storageName,storageSpace,storageUnit)
        return usage 
    }
    Usage chargeTime(String chargeUser, String timeName,BigDecimal chargetime, TimeUnit timeUnit) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UsageService usageService = serviceAPI.buildUsageService()
        Usage usage = usageService.chargeTime(chargeUser,timeName,chargetime,timeUnit)
        return usage 
    }
    Usage getAllLevelUsage() throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UsageService usageService = serviceAPI.buildUsageService()
        Usage usage = usageService.getAllLevelUsage()
        return usage 
    }
    Usage getAllOneTimeUsage() throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UsageService usageService = serviceAPI.buildUsageService()
        Usage usage = usageService.getAllOneTimeUsage()
        return usage 
    }
    Usage getAllFeatureUsage() throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UsageService usageService = serviceAPI.buildUsageService()
        Usage usage = usageService.getAllFeatureUsage()
        return usage 
    }
    Usage getAllTimeUsage() throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UsageService usageService = serviceAPI.buildUsageService()
        Usage usage = usageService.getAllTimeUsage()
        return usage 
    }
     Usage getAllStorageUsage() throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UsageService usageService = serviceAPI.buildUsageService()
        Usage usage = usageService.getAllStorageUsage()
        return usage 
    }
    Usage getAllBandwidthUsage() throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UsageService usageService = serviceAPI.buildUsageService()
        Usage usage = usageService.getAllBandwidthUsage()
        return usage 
    }
}
