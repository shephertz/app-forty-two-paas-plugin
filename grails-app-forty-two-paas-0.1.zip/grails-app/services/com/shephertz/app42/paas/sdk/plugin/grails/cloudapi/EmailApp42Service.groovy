package com.shephertz.app42.paas.sdk.plugin.grails.cloudapi

import com.shephertz.app42.paas.sdk.java.ServiceAPI
import com.shephertz.app42.paas.sdk.java.email.Email
import com.shephertz.app42.paas.sdk.java.email.EmailService
import com.shephertz.app42.paas.sdk.java.email.EmailMIME
import com.shephertz.app42.paas.sdk.java.App42Exception
import com.shephertz.app42.paas.sdk.java.App42Response


class EmailApp42Service {

    static transactional = true
    static scope = "request"
    
    def apiService
    

    Email createMailConfiguration(String emailHost, int emailPort, String mailId, String emailPassword, boolean isSSL) throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        EmailService emailService = serviceAPI.buildEmailService()
        Email email = emailService.createMailConfiguration(emailHost,emailPort,mailId,emailPassword,isSSL)
        return email
    }
    
    App42Response removeEmailConfiguration(String emailId) throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        EmailService emailService = serviceAPI.buildEmailService()
        App42Response response = emailService.removeEmailConfiguration(emailId)
        return response
    }
    
    Email getEmailConfigurations() throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        EmailService emailService = serviceAPI.buildEmailService()
        Email email = emailService.getEmailConfigurations()
        return email
    }
    
    Email sendMail(String sendTo, String sendSubject, String sendMsg, String fromEmail, EmailMIME emailMime) throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        EmailService emailService = serviceAPI.buildEmailService()
        Email email = emailService.sendMail(sendTo, sendSubject, sendMsg, fromEmail, emailMime)
        return email
    }
}
