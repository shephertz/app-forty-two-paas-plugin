package com.shephertz.app42.paas.sdk.plugin.grails
import com.shephertz.app42.paas.sdk.java.ServiceAPI
import com.shephertz.app42.paas.sdk.java.ConfigurationException
class ApiService {

    static transactional = true

    String apiKey
    String secretKey
    
    ServiceAPI getServiceAPI(){
        //Have to check whether this is the right way to get base dir
        def config = new ConfigSlurper().parse(new File("grails-app/conf/App42Config.groovy").toURL())
        if(config == null){
            new ConfigurationException("App42Config file should be present in the conf directory")
        }
        apiKey = config.app42.app.apiKey
        secretKey = config.app42.app.secretKey
        if(apiKey == null || secretKey == null){
            new ConfigurationException("Api Key and Secret Key has to be specified in the App42Config.groovy file in the conf directory")
        }
        println "API KEY ${apiKey} SECRET ${secretKey}"
        ServiceAPI api = new ServiceAPI(apiKey,secretKey);
        return api
    }
    
    String setApikey(String apiKey){
        apiKey = apiKey
    }
    
    
    String getApiKey() {
        return apiKey
    }
    
    String setSecretkey(String apiKey){
        secretKey = secretKey
    }
    
    String getSecretKey() {
        return secretKey
    }
}
