package com.shephertz.app42.paas.sdk.plugin.grails.cloudapi
import com.shephertz.app42.paas.sdk.java.ServiceAPI
import com.shephertz.app42.paas.sdk.java.user.User
import com.shephertz.app42.paas.sdk.java.user.UserService
import com.shephertz.app42.paas.sdk.java.App42Exception
import com.shephertz.app42.paas.sdk.java.App42Response

class UserApp42Service {

    static transactional = true
    static scope = "request"
    
    
    def apiService
    
    User createUser(String userName, password, emailAddress) {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UserService userService = serviceAPI.buildUserService()
        User user = userService.createUser(userName, password, emailAddress);
        return user;
    }
    
    User createUser(String userName, String password, String emailAddress,ArrayList<String> roleList) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UserService userService = serviceAPI.buildUserService()
        User user = userService.createUser(userName, password, emailAddress, roleList);
        return user;
        
    }
    
    
    User getUser(String userName){
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UserService userService = serviceAPI.buildUserService()
        User user = userService.getUser(userName)
        return user;
    }
    
    ArrayList<User> getAllUsers() throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UserService userService = serviceAPI.buildUserService()
        ArrayList<User> users = userService.getAllUsers()
        return users;
    }
    
    User getUserByEmailId(String emailId) throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UserService userService = serviceAPI.buildUserService()
        User user = userService.getUserByEmailId(emailId)
        return user;
    }
    
    ArrayList<User> getLockedUsers() throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UserService userService = serviceAPI.buildUserService()
        ArrayList<User> users = userService.getLockedUsers()
        return users;
    }
    
    User updateEmail(String uName, String emailAddress) throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UserService userService = serviceAPI.buildUserService()
        User user = userService.updateEmail(uName, emailAddress)
        return user;
    }
    
    App42Response deleteUser(String userName) throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UserService userService = serviceAPI.buildUserService()
         App42Response response = userService.deleteUser(userName)
         return response
    }
        
    User createOrUpdateProfile(User userObj)throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UserService userService = serviceAPI.buildUserService()
        User user = userService.createOrUpdateProfile(userObj)
        return user;
    }
    
    App42Response authenticate(String uName, String pwd)throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UserService userService = serviceAPI.buildUserService()
         App42Response response = userService.authenticate(uName, pwd)
         return response
    }
    
    User unlockUser(String uName) throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UserService userService = serviceAPI.buildUserService()
        User user = userService.unlockUser(uName)
        return user;
    }
    
    
    User lockUser(String uName) throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UserService userService = serviceAPI.buildUserService()
        User user = userService.lockUser(uName)
        return user;
    }
    
    App42Response changeUserPassword(String uName, String oldPwd, String newPwd) throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UserService userService = serviceAPI.buildUserService()
         App42Response response = userService.changeUserPassword(uName, oldPwd, newPwd)
         return response
    }
    
    User assignRoles(String uName, ArrayList<String> roleList) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UserService userService = serviceAPI.buildUserService()
        User user = userService.assignRoles(uName, roleList)
        return user;
    }
    
    App42Response revokeRole(String userName, String role) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UserService userService = serviceAPI.buildUserService()
         App42Response response = userService.revokeRole(userName, role)
         return response
    }
   
    App42Response revokeAllRoles(String userName) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UserService userService = serviceAPI.buildUserService()
         App42Response response = userService.revokeAllRoles(userName)
         return response
    }
    
    User getRolesByUser(String userName) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UserService userService = serviceAPI.buildUserService()
        User user = userService.getRolesByUser(userName)
        return user;
    }	
       
    ArrayList<User> getUsersByRole(String role) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UserService userService = serviceAPI.buildUserService()
        ArrayList<User> users = userService.getUsersByRole(role)
        return users;
    }
    
    ArrayList<User> getUsersByProfileData(User.Profile profileData) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UserService userService = serviceAPI.buildUserService()
        ArrayList<User> users = userService.getUsersByProfileData(profileData)
        return users;
    }
    
    App42Response getAllUsersCount() throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UserService userService = serviceAPI.buildUserService()
        App42Response response = userService.getAllUsersCount()
        return response
    }
    
    App42Response getLockedUsersCount() throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UserService userService = serviceAPI.buildUserService()
        App42Response response = userService.getLockedUsersCount()
        return response
    }
    
    ArrayList<User> getAllUsers(int max, int offset){
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UserService userService = serviceAPI.buildUserService()
        ArrayList<User> users = userService.getAllUsers(max, offset)
        return users;
    }
    
    ArrayList<User> getLockedUsers(int max, int offset){
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UserService userService = serviceAPI.buildUserService()
        ArrayList<User> users = userService.getLockedUsers(max, offset)
        return users;
    }
    
    App42Response resetUserPassword(String uName, String pwd){
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        UserService userService = serviceAPI.buildUserService()
        App42Response response = userService.resetUserPassword(uName, pwd)
        return response
    }
    
}
