package com.shephertz.app42.paas.sdk.plugin.grails.cloudapi

import com.shephertz.app42.paas.sdk.java.ServiceAPI
import com.shephertz.app42.paas.sdk.java.push.PushNotification
import com.shephertz.app42.paas.sdk.java.push.DeviceType
import com.shephertz.app42.paas.sdk.java.push.PushNotificationResponseBuilder
import com.shephertz.app42.paas.sdk.java.push.PushNotificationService
import com.shephertz.app42.paas.sdk.java.App42Exception
import com.shephertz.app42.paas.sdk.java.App42Response

class PushNotificationApp42Service {

    static transactional = true
    static scope = "request"
    
    def apiService
    
    PushNotification storeDeviceToken(String userName, String deviceToken,DeviceType deviceType) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        PushNotificationService pushNotificationService = serviceAPI.buildPushNotificationService()
        PushNotification pushNotification = pushNotificationService.storeDeviceToken(userName,deviceToken,deviceType)
        return pushNotification 
    } 
    
    PushNotification createChannelForApp(String channel,String description) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        PushNotificationService pushNotificationService = serviceAPI.buildPushNotificationService()
        PushNotification pushNotification = pushNotificationService.createChannelForApp(channel,description)
        return pushNotification 

    } 
    PushNotification subscribeToChannel(String channel,String userName) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        PushNotificationService pushNotificationService = serviceAPI.buildPushNotificationService()
        PushNotification pushNotification = pushNotificationService.subscribeToChannel(channel,userName)
        return pushNotification 
    } 
    PushNotification unsubscribeFromChannel(String channel,String userName) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        PushNotificationService pushNotificationService = serviceAPI.buildPushNotificationService()
        PushNotification pushNotification = pushNotificationService.unsubscribeFromChannel(channel,userName)
        return pushNotification 
    } 
    PushNotification sendPushMessageToChannel(String channel,String message) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        PushNotificationService pushNotificationService = serviceAPI.buildPushNotificationService()
        PushNotification pushNotification = pushNotificationService.sendPushMessageToChannel(channel,message)
        return pushNotification 
    } 
    PushNotification sendPushMessageToAll(String message) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        PushNotificationService pushNotificationService = serviceAPI.buildPushNotificationService()
        PushNotification pushNotification = pushNotificationService.uploadApiKey(message)
        return pushNotification 
    } 
    PushNotification sendPushMessageToUser(String username,String message) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        PushNotificationService pushNotificationService = serviceAPI.buildPushNotificationService()
        PushNotification pushNotification = pushNotificationService.sendPushMessageToUser(username,message)
        return pushNotification 
    }
}