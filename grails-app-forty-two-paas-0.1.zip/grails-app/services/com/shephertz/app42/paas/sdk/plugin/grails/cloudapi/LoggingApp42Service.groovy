package com.shephertz.app42.paas.sdk.plugin.grails.cloudapi

import com.shephertz.app42.paas.sdk.java.ServiceAPI
import com.shephertz.app42.paas.sdk.java.log.Log
import com.shephertz.app42.paas.sdk.java.log.LogService
import com.shephertz.app42.paas.sdk.java.App42Exception
import com.shephertz.app42.paas.sdk.java.App42Response

class LoggingApp42Service {

    static transactional = true
    static scope = "request"
    
    def apiService
    

    Log info(String msg, String module) throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        LogService logService = serviceAPI.buildLogService()
        Log log = logService.info(msg,module)
        return log
    }
    
    Log debug(String msg, String module) throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        LogService logService = serviceAPI.buildLogService()
        Log log = logService.debug(msg,module)
        return log
    }
    
    Log fatal(String msg, String module) throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        LogService logService = serviceAPI.buildLogService()
        Log log = logService.fatal(msg,module)
        return log
    }
    
    Log error(String msg, String module) throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        LogService logService = serviceAPI.buildLogService()
        Log log = logService.error(msg,module)
        return log
    }
    
    Log fetchLogsByModule(String moduleName) throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        LogService logService = serviceAPI.buildLogService()
        Log log = logService.fetchLogsByModule(moduleName);
        return log
    }
    
    Log fetchLogsByModuleAndText(String moduleName, String text)throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        LogService logService = serviceAPI.buildLogService()
        Log log = logService.fetchLogsByModuleAndText(moduleName, text)
        return log
    }
    
    Log fetchLogsByInfo() throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        LogService logService = serviceAPI.buildLogService()
        Log log = logService.fetchLogsByInfo()
        return log
    }
    
    Log fetchLogsByDebug() throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        LogService logService = serviceAPI.buildLogService()
        Log log = logService.fetchLogsByDebug()
        return log
    }
    
    Log fetchLogsByError() throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        LogService logService = serviceAPI.buildLogService()
        Log log = logService.fetchLogsByError()
        return log
    }
    
    Log fetchLogsByFatal() throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        LogService logService = serviceAPI.buildLogService()
        Log log = logService.fetchLogsByFatal()
        return log
    }
    
    
    App42Response fetchLogsCountByModule(String moduleName) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        LogService logService = serviceAPI.buildLogService()
        return logService.fetchLogsCountByModule(moduleName)
    }
    
    Log fetchLogsByModule(String moduleName, int max, int offset) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        LogService logService = serviceAPI.buildLogService()
        Log log = logService.fetchLogsByModule(moduleName, max, offset)
        return log
    }
    
    App42Response fetchLogsCountByModuleAndText(String moduleName, String text) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        LogService logService = serviceAPI.buildLogService()
        return logService.fetchLogsCountByModuleAndText(moduleName, text)
    }
    
    Log fetchLogsByModuleAndText(String moduleName, String text, int max, int offset) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        LogService logService = serviceAPI.buildLogService()
        Log log = logService.fetchLogsByModuleAndText(moduleName, text, max, offset)
        return log
    }
    
    App42Response fetchLogsCountByInfo() throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        LogService logService = serviceAPI.buildLogService()
        return logService.fetchLogsCountByInfo()
    }
    
    App42Response fetchLogsCountByDebug() throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        LogService logService = serviceAPI.buildLogService()
        return logService.fetchLogsCountByDebug()
    }
    
    App42Response fetchLogsCountByError() throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        LogService logService = serviceAPI.buildLogService()
        return logService.fetchLogsCountByError()
    }
    
    App42Response fetchLogsCountByFatal() throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        LogService logService = serviceAPI.buildLogService()
        return logService.fetchLogsCountByFatal()
    }
    
    Log fetchLogsByInfo(int max, int offset) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        LogService logService = serviceAPI.buildLogService()
        Log log = logService.fetchLogsByInfo(max, offset)
        return log
    }
    
    Log fetchLogsByDebug(int max, int offset) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        LogService logService = serviceAPI.buildLogService()
        Log log = logService.fetchLogsByDebug(max, offset)
        return log
    }
     
    Log fetchLogsByError(int max, int offset) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        LogService logService = serviceAPI.buildLogService()
        Log log = logService.fetchLogsByError(max, offset)
        return log
    }
    
    Log fetchLogsByFatal(int max, int offset) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        LogService logService = serviceAPI.buildLogService()
        Log log = logService.fetchLogsByFatal(max, offset)
        return log
    }
    
    App42Response fetchLogCountByDateRange(Date startDate, Date endDate) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        LogService logService = serviceAPI.buildLogService()
        return logService.fetchLogCountByDateRange(startDate, endDate)               
    }
    
    Log fetchLogByDateRange(Date startDate, Date endDate) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        LogService logService = serviceAPI.buildLogService()
        Log log = logService.fetchLogByDateRange(startDate, endDate)
        return log
    }
    
}
