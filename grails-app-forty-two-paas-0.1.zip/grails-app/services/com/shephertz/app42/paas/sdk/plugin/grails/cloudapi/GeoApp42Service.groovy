package com.shephertz.app42.paas.sdk.plugin.grails.cloudapi

import com.shephertz.app42.paas.sdk.java.ServiceAPI
import com.shephertz.app42.paas.sdk.java.geo.Geo
import com.shephertz.app42.paas.sdk.java.geo.GeoPoint
import com.shephertz.app42.paas.sdk.java.geo.GeoService
import com.shephertz.app42.paas.sdk.java.App42Exception
import com.shephertz.app42.paas.sdk.java.App42Response

class GeoApp42Service {

    static transactional = true
    static scope = "request"
    
    def apiService
    
    Geo createGeoPoints(String geoStorageName,ArrayList<GeoPoint> geoPointsList) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        GeoService geoService = serviceAPI.buildGeoService()
        Geo geo = geoService.createGeoPoints(geoStorageName, geoPointsList)
        return geo
    }
    
    Geo getNearByPointsByMaxDistance(String storageName,BigDecimal lat, BigDecimal lng, BigDecimal distanceInKM) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        GeoService geoService = serviceAPI.buildGeoService()
        Geo geo = geoService.getNearByPointsByMaxDistance(storageName, lat, lng, distanceInKM)
        return geo
    }
    
    Geo getNearByPoint(String storageName, BigDecimal lat, BigDecimal lng, int resultLimit) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        GeoService geoService = serviceAPI.buildGeoService()
        Geo geo = geoService.getNearByPoint(storageName, lat, lng, resultLimit)
        return geo
    }

    Geo getPointsWithInCircle(String storageName, BigDecimal lat, BigDecimal lng, BigDecimal radiusInKM, int resultLimit) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        GeoService geoService = serviceAPI.buildGeoService()
        Geo geo = geoService.getPointsWithInCircle(storageName, lat, lng, radiusInKM, resultLimit)
        return geo
    }
    
    ArrayList<Geo> getAllStorage() throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        GeoService geoService = serviceAPI.buildGeoService()
        ArrayList<GeoPoint> geoList = geoService.getAllStorage()
        return geoList
    }
    
    App42Response deleteStorage(String storageName) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        GeoService geoService = serviceAPI.buildGeoService()
        return geoService.deleteStorage(storageName)
    }

    Geo getAllPoints(String storageName) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        GeoService geoService = serviceAPI.buildGeoService()
        Geo geo = geoService.getAllPoints(storageName)
        return geo
    }
    
}
