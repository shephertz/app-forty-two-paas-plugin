package com.shephertz.app42.paas.sdk.plugin.grails.cloudapi

import com.shephertz.app42.paas.sdk.java.ServiceAPI
import com.shephertz.app42.paas.sdk.java.appTab.Bill
import com.shephertz.app42.paas.sdk.java.appTab.BillMonth
import com.shephertz.app42.paas.sdk.java.appTab.BillService

import com.shephertz.app42.paas.sdk.java.App42Exception
import com.shephertz.app42.paas.sdk.java.App42Response

class BillApp42Service {

    static transactional = true
    static scope = "request"
    
    def apiService
    
    Bill usageTimeByMonthAndYear(String userName, String usageName,BillMonth billMonth, int year) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        BillService billService = serviceAPI.buildBillService()
        Bill bill = billService.usageTimeByMonthAndYear(userName, usageName,billMonth,year)
        return bill 
    }
    Bill usageStorageByMonthAndYear(String userName, String usageName,BillMonth billMonth, int year) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        BillService billService = serviceAPI.buildBillService()
        Bill bill = billService.usageStorageByMonthAndYear(userName, usageName,billMonth,year)
        return bill 
    }
    Bill usageBandwidthByMonthAndYear(String userName, String usageName,BillMonth billMonth, int year) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        BillService billService = serviceAPI.buildBillService()
        Bill bill = billService.usageBandwidthByMonthAndYear(userName, usageName,billMonth,year)
        return bill 
    }
    Bill usageLevelByMonthAndYear(String userName, String usageName,BillMonth billMonth, int year) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        BillService billService = serviceAPI.buildBillService()
        Bill bill = billService.usageLevelByMonthAndYear(userName, usageName,billMonth,year)
        return bill 
    }
    Bill usageOneTimeByMonthAndYear(String userName, String usageName,BillMonth billMonth, int year) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        BillService billService = serviceAPI.buildBillService()
        Bill bill = billService.usageOneTimeByMonthAndYear(userName, usageName,billMonth,year)
        return bill 
    }
    Bill usageFeatureByMonthAndYear(String userName, String usageName,BillMonth billMonth, int year) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        BillService billService = serviceAPI.buildBillService()
        Bill bill = billService.usageFeatureByMonthAndYear(userName, usageName,billMonth,year)
        return bill 
    }
    Bill usageLicenseByMonthAndYear(String userName, String licenseName,BillMonth billMonth, int year) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        BillService billService = serviceAPI.buildBillService()
        Bill bill = billService.usageLicenseByMonthAndYear(userName, licenseName,billMonth,year)
        return bill 
    }
}
