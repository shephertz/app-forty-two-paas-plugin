package com.shephertz.app42.paas.sdk.plugin.grails.cloudapi

import com.shephertz.app42.paas.sdk.java.ServiceAPI
import com.shephertz.app42.paas.sdk.java.recommend.RecommenderSimilarity
import com.shephertz.app42.paas.sdk.java.recommend.PreferenceData
import com.shephertz.app42.paas.sdk.java.recommend.Recommender
import com.shephertz.app42.paas.sdk.java.recommend.RecommenderService
import com.shephertz.app42.paas.sdk.java.App42Exception
import com.shephertz.app42.paas.sdk.java.App42Response

class RecommenderApp42Service {

    static transactional = true
    static scope = "request"
    
    def apiService
    
    App42Response loadPreferenceFile(String preferenceFilePath) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        RecommenderService recommenderService = serviceAPI.buildRecommenderService()
        return recommenderService.loadPreferenceFile(preferenceFilePath)
    }
    
    App42Response loadPreferenceFile(InputStream inputStream) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        RecommenderService recommenderService = serviceAPI.buildRecommenderService()
        return recommenderService.loadPreferenceFile(inputStream)
    }
    
    App42Response addOrUpdatePreference(ArrayList<PreferenceData> preferenceDataList) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        RecommenderService recommenderService = serviceAPI.buildRecommenderService()
        return recommenderService.addOrUpdatePreference(preferenceDataList)
    }

    Recommender userBasedNeighborhood(long userId, int size, int howMany) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        RecommenderService recommenderService = serviceAPI.buildRecommenderService()
        Recommender recommender = recommenderService.userBasedNeighborhood(userId, size, howMany)
        return recommender
    }
    
    Recommender userBasedThreshold(long userId, double threshold,int howMany) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        RecommenderService recommenderService = serviceAPI.buildRecommenderService()
        Recommender recommender = recommenderService.userBasedThreshold(userId, threshold, howMany)
        return recommender
    }
    
    Recommender userBasedNeighborhoodBySimilarity(RecommenderSimilarity recommenderSimilarity, long userId, int size, int howMany) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        RecommenderService recommenderService = serviceAPI.buildRecommenderService()
        Recommender recommender = recommenderService.userBasedNeighborhoodBySimilarity(recommenderSimilarity, userId, size, howMany)
        return recommender
    }
    
    Recommender userBasedThresholdBySimilarity(RecommenderSimilarity recommenderSimilarity, long userId, double threshold, int howMany) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        RecommenderService recommenderService = serviceAPI.buildRecommenderService()
        Recommender recommender = recommenderService.userBasedThresholdBySimilarity(recommenderSimilarity, userId, threshold, howMany)
        return recommender
    }
    
    Recommender itemBased(long userId, int howMany) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        RecommenderService recommenderService = serviceAPI.buildRecommenderService()
        Recommender recommender = recommenderService.itemBased(userId, howMany)
        return recommender
    }
    
    Recommender slopeOne(long userId, int howMany) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        RecommenderService recommenderService = serviceAPI.buildRecommenderService()
        Recommender recommender = recommenderService.slopeOne(userId, howMany)
        return recommender
    }

    Recommender userBasedThresholdForAll(double threshold, int howMany) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        RecommenderService recommenderService = serviceAPI.buildRecommenderService()
        Recommender recommender = recommenderService.userBasedThresholdForAll(threshold, howMany)
        return recommender
    }
    
    Recommender userBasedNeighborhoodBySimilarityForAll(RecommenderSimilarity recommenderSimilarity, int size, int howMany) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        RecommenderService recommenderService = serviceAPI.buildRecommenderService()
        Recommender recommender = recommenderService.userBasedNeighborhoodBySimilarityForAll(recommenderSimilarity, size, howMany)
        return recommender                    
    }
    
    Recommender userBasedThresholdBySimilarityForAll(RecommenderSimilarity recommenderSimilarity, double threshold,int howMany) throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        RecommenderService recommenderService = serviceAPI.buildRecommenderService()
        Recommender recommender = recommenderService.userBasedThresholdBySimilarityForAll(recommenderSimilarity, threshold, howMany)
        return recommender      
    }
    
    Recommender itemBasedForAll(int howMany) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        RecommenderService recommenderService = serviceAPI.buildRecommenderService()
        Recommender recommender = recommenderService.itemBasedForAll(howMany)
        return recommender      
    }

    Recommender itemBasedBySimilarityForAll(RecommenderSimilarity recommenderSimilarity, int howMany) throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        RecommenderService recommenderService = serviceAPI.buildRecommenderService()
        Recommender recommender = recommenderService.itemBasedBySimilarityForAll(recommenderSimilarity, howMany)
        return recommender  
    }
    
    Recommender slopeOneForAll(int howMany) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        RecommenderService recommenderService = serviceAPI.buildRecommenderService()
        Recommender recommender = recommenderService.slopeOneForAll(howMany)
        return recommender  
    }
    
    Recommender itemBasedBySimilarity(RecommenderSimilarity recommenderSimilarity, long userId,int howMany) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        RecommenderService recommenderService = serviceAPI.buildRecommenderService()
        Recommender recommender = recommenderService.itemBasedBySimilarity(recommenderSimilarity, userId, howMany)
        return recommender  
    }
    
    Recommender userBasedNeighborhoodForAll(int size, int howMany) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        RecommenderService recommenderService = serviceAPI.buildRecommenderService()
        Recommender recommender = recommenderService.userBasedNeighborhoodForAll(size, howMany)
        return recommender  
    }
    
    App42Response deleteAllPreferences() throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        RecommenderService recommenderService = serviceAPI.buildRecommenderService()
        return recommenderService.deleteAllPreferences()
    }
    
    
    
    
    
}
