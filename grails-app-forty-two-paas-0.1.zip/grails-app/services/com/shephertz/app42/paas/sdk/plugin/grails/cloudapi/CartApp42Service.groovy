package com.shephertz.app42.paas.sdk.plugin.grails.cloudapi

import com.shephertz.app42.paas.sdk.java.ServiceAPI
import com.shephertz.app42.paas.sdk.java.shopping.Cart
import com.shephertz.app42.paas.sdk.java.shopping.PaymentStatus
import com.shephertz.app42.paas.sdk.java.shopping.CartService
import com.shephertz.app42.paas.sdk.java.App42Exception
import com.shephertz.app42.paas.sdk.java.App42Response

class CartApp42Service {

    static transactional = true
    static scope = "request"
    
    def apiService
    
    Cart createCart(String user) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        CartService cartService = serviceAPI.buildCartService()
        Cart cart = cartService.createCart(user)
        return cart
    }
    
    Cart getCartDetails(String cartId) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        CartService cartService = serviceAPI.buildCartService()
        Cart cart = cartService.getCartDetails(cartId)
        return cart
    }
    
    Cart addItem(String cartID, String itemID, int itemQuantity, double price) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        CartService cartService = serviceAPI.buildCartService()
        Cart cart = cartService.addItem(cartID, itemID, itemQuantity, price)
        return cart
    }
    
    Cart getItems(String cartId) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        CartService cartService = serviceAPI.buildCartService()
        Cart cart = cartService.getItems(cartId)
        return cart
    }
    
    Cart getItem(String cartId, String itemId) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        CartService cartService = serviceAPI.buildCartService()
        Cart cart = cartService.getItem(cartId, itemId)
        return cart
    }
    
    App42Response removeItem(String cartId, String itemId) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        CartService cartService = serviceAPI.buildCartService()
        return cartService.removeItem(cartId, itemId)
    }
    
    App42Response removeAllItems(String cartId) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        CartService cartService = serviceAPI.buildCartService()
        return cartService.removeAllItems(cartId)
    }
    
    Cart isEmpty(String cartId) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        CartService cartService = serviceAPI.buildCartService()
        Cart cart = cartService.isEmpty(cartId)
        return cart
    }
    
    Cart checkOut(String cartID) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        CartService cartService = serviceAPI.buildCartService()
        Cart cart = cartService.checkOut(cartID)
        return cart
    }
    
    Cart payment(String cartID, String transactionID, PaymentStatus paymentStatus) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        CartService cartService = serviceAPI.buildCartService()
        Cart cart = cartService.payment(cartID, transactionID, paymentStatus)
        return cart
    }
    
    ArrayList<Cart> getPaymentsByUser(String userId) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        CartService cartService = serviceAPI.buildCartService()
        ArrayList<Cart> cartList = cartService.getPaymentsByUser(userId)
        return cartList
    }
    
    Cart getPaymentByCart(String cartId) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        CartService cartService = serviceAPI.buildCartService()
        Cart cart = cartService.getPaymentByCart(cartId)
        return cart
    }
    
    ArrayList<Cart> getPaymentsByUserAndStatus(String userId, PaymentStatus paymentStatus) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        CartService cartService = serviceAPI.buildCartService()
        ArrayList<Cart> cartList = cartService.getPaymentsByUserAndStatus(userId, paymentStatus)
        return cartList
    }
    
    ArrayList<Cart> getPaymentsByStatus(PaymentStatus paymentStatus) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        CartService cartService = serviceAPI.buildCartService()
        ArrayList<Cart> cartList = cartService.getPaymentsByStatus(paymentStatus)
        return cartList
    }
    
    ArrayList<Cart> getPaymentHistoryByUser(String userId) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        CartService cartService = serviceAPI.buildCartService()
        ArrayList<Cart> cartList = cartService.getPaymentHistoryByUser(userId)
        return cartList
    }
    
    ArrayList<Cart> getPaymentHistoryAll() throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        CartService cartService = serviceAPI.buildCartService()
        ArrayList<Cart> cartList = cartService.getPaymentHistoryAll()
        return cartList
    }
    
    Cart increaseQuantity(String cartID, String itemID, int itemQuantity) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        CartService cartService = serviceAPI.buildCartService()
        Cart cart = cartService.increaseQuantity(cartID, itemID, itemQuantity)
        return cart
    }
    
    Cart decreaseQuantity(String cartID, String itemID, int itemQuantity) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        CartService cartService = serviceAPI.buildCartService()
        Cart cart = cartService.decreaseQuantity(cartID, itemID, itemQuantity)
        return cart
    }
    
    
}
