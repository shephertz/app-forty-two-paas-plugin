package com.shephertz.app42.paas.sdk.plugin.grails.cloudapi

import com.shephertz.app42.paas.sdk.java.ServiceAPI
import com.shephertz.app42.paas.sdk.java.shopping.Catalogue
import com.shephertz.app42.paas.sdk.java.shopping.PaymentStatus
import com.shephertz.app42.paas.sdk.java.shopping.CatalogueService
import com.shephertz.app42.paas.sdk.java.shopping.ItemData
import com.shephertz.app42.paas.sdk.java.App42Exception
import com.shephertz.app42.paas.sdk.java.App42Response

class CatalogueApp42Service {

    static transactional = true
    static scope = "request"
    
    def apiService
    
    Catalogue createCatalogue(String catalogueName, String catalogueDescription) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        CatalogueService catalogueService = serviceAPI.buildCatalogueService()
        Catalogue catalogue = catalogueService.createCatalogue(catalogueName, catalogueDescription)
        return catalogue 
    }
    
    Catalogue createCategory(String catalogueName, String categoryName, String categoryDescription) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        CatalogueService catalogueService = serviceAPI.buildCatalogueService()
        Catalogue catalogue = catalogueService.createCategory(catalogueName, categoryName, categoryDescription)
        return catalogue
    }
    
    Catalogue addItem(String catalogueName, String categoryName, ItemData itemData) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        CatalogueService catalogueService = serviceAPI.buildCatalogueService()
        Catalogue catalogue = catalogueService.addItem(catalogueName, categoryName, itemData)
        return catalogue
    }
    
    Catalogue getItems(String catalogueName) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        CatalogueService catalogueService = serviceAPI.buildCatalogueService()
        Catalogue catalogue = catalogueService.getItems(catalogueName)
        return catalogue
    }
    
    Catalogue getItemsByCategory(String catalogueName, String categoryName) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        CatalogueService catalogueService = serviceAPI.buildCatalogueService()
        Catalogue catalogue = catalogueService.getItemsByCategory(catalogueName, categoryName)
        return catalogue
    }
    
    App42Response getItemsCountByCategory(String catalogueName, String categoryName) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        CatalogueService catalogueService = serviceAPI.buildCatalogueService()
        App42Response response =  catalogueService.getItemsCountByCategory(catalogueName, categoryName)
        return response
    }
    
    Catalogue getItemsByCategory(String catalogueName, String categoryName, int max, int offset) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        CatalogueService catalogueService = serviceAPI.buildCatalogueService()
        Catalogue catalogue = catalogueService.getItemsByCategory(catalogueName, categoryName, max, offset)
        return catalogue
    }

    Catalogue getItemById(String catalogueName, String categoryName, String itemId) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        CatalogueService catalogueService = serviceAPI.buildCatalogueService()
        Catalogue catalogue = catalogueService.getItemById(catalogueName, categoryName, itemId)
        return catalogue
    }
    
    App42Response removeAllItems(String catalogueName) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        CatalogueService catalogueService = serviceAPI.buildCatalogueService()
        App42Response response =  catalogueService.removeAllItems(catalogueName)
        return response
    }
    
    App42Response removeItemsByCategory(String catalogueName, String categoryName) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        CatalogueService catalogueService = serviceAPI.buildCatalogueService()
        App42Response response =  catalogueService.removeItemsByCategory(catalogueName, categoryName)
        return response
    }
    
    App42Response removeItemById(String catalogueName, String categoryName, String itemId) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        CatalogueService catalogueService = serviceAPI.buildCatalogueService()
        App42Response response =  catalogueService.removeItemById(catalogueName, categoryName, itemId)
        return response
    }
    
    
    
}
