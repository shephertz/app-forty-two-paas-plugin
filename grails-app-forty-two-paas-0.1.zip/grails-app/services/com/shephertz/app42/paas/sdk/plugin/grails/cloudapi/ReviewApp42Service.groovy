package com.shephertz.app42.paas.sdk.plugin.grails.cloudapi

import com.shephertz.app42.paas.sdk.java.ServiceAPI
import com.shephertz.app42.paas.sdk.java.review.Review
import com.shephertz.app42.paas.sdk.java.review.ReviewService
import com.shephertz.app42.paas.sdk.java.App42Exception
import com.shephertz.app42.paas.sdk.java.App42Response

class ReviewApp42Service {

    static transactional = true
    static scope = "request"
    
    def apiService
    
    Review createReview(String userID, String itemID,String reviewComment, double reviewRating) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        ReviewService reviewService = serviceAPI.buildReviewService()
        Review review = reviewService.createReview(userID, itemID, reviewComment, reviewRating)
        return review
    }
    
    ArrayList<Review> getAllReviews() throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        ReviewService reviewService = serviceAPI.buildReviewService()
        ArrayList<Review> reviewList = reviewService.getAllReviews()
        return reviewList
    }

    App42Response getAllReviewsCount() throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        ReviewService reviewService = serviceAPI.buildReviewService()
        return reviewService.getAllReviewsCount()
    }

    ArrayList<Review> getAllReviews(int max, int offset) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        ReviewService reviewService = serviceAPI.buildReviewService()
        ArrayList<Review> reviewList = reviewService.getAllReviews(max, offset)
        return reviewList
    }
    
    App42Response getReviewsCountByItem(String itemId) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        ReviewService reviewService = serviceAPI.buildReviewService()
        return reviewService.getReviewsCountByItem(itemId)
    }
    
    ArrayList<Review> getReviewsByItem(String itemId) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        ReviewService reviewService = serviceAPI.buildReviewService()
        ArrayList<Review> reviewList = reviewService.getReviewsByItem(itemId)
        return reviewList
    }
    
    ArrayList<Review> getReviewsByItem(String itemId, int max, int offset) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        ReviewService reviewService = serviceAPI.buildReviewService()
        ArrayList<Review> reviewList = reviewService.getReviewsByItem(itemId, max, offset)
        return reviewList
    }
    
    Review getHighestReviewByItem(String itemId) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        ReviewService reviewService = serviceAPI.buildReviewService()
        Review review = reviewService.getHighestReviewByItem(itemId)
        return review
    }

    Review getLowestReviewByItem(String itemId) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        ReviewService reviewService = serviceAPI.buildReviewService()
        Review review = reviewService.getLowestReviewByItem(itemId)
        return review
    }

    Review getAverageReviewByItem(String itemId) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        ReviewService reviewService = serviceAPI.buildReviewService()
        Review review = reviewService.getAverageReviewByItem(itemId)
        return review
    }

    App42Response mute(String reviewId) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        ReviewService reviewService = serviceAPI.buildReviewService()
        return reviewService.mute(reviewId)
    }
    
    App42Response unmute(String reviewId) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        ReviewService reviewService = serviceAPI.buildReviewService()
        return reviewService.unmute(reviewId)
    }
    
    
}
