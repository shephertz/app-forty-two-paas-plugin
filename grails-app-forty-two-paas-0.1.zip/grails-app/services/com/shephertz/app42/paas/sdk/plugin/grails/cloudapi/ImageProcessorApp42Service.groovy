package com.shephertz.app42.paas.sdk.plugin.grails.cloudapi

import com.shephertz.app42.paas.sdk.java.ServiceAPI
import com.shephertz.app42.paas.sdk.java.imageProcessor.Image
import com.shephertz.app42.paas.sdk.java.imageProcessor.ImageProcessorService
import com.shephertz.app42.paas.sdk.java.App42Exception
import com.shephertz.app42.paas.sdk.java.App42Response

class ImageProcessorApp42Service {

    static transactional = true
    static scope = "request"
    
    def apiService
    
    
    Image resize(String name, String imagePath, Integer width, Integer height) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        ImageProcessorService imageProcessorService = serviceAPI.buildImageProcessorService()
        Image image = imageProcessorService.resize(name, imagePath, width, height)
        return image
    }
    
    Image thumbnail(String name, String imagePath, Integer width, Integer height) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        ImageProcessorService imageProcessorService = serviceAPI.buildImageProcessorService()
        Image image = imageProcessorService.thumbnail(name, imagePath, width, height)
        return image
    }
    
    Image scale(String name, String imagePath, Integer width, Integer height) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        ImageProcessorService imageProcessorService = serviceAPI.buildImageProcessorService()
        Image image = imageProcessorService.scale(name, imagePath, width, height)
        return image
    }
    
    Image crop(String name, String imagePath, Integer width, Integer height, Integer x, Integer y) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        ImageProcessorService imageProcessorService = serviceAPI.buildImageProcessorService()
        Image image = imageProcessorService.crop(name, imagePath, width, height, x, y)
        return image
    }

    Image resizeByPercentage(String name, String imagePath, Double percentage) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        ImageProcessorService imageProcessorService = serviceAPI.buildImageProcessorService()
        Image image = imageProcessorService.resizeByPercentage(name, imagePath, percentage)
        return image
    }
    
    Image thumbnailByPercentage(String name, String imagePath, Double percentage) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        ImageProcessorService imageProcessorService = serviceAPI.buildImageProcessorService()
        Image image = imageProcessorService.thumbnailByPercentage(name, imagePath, percentage)
        return image
    }
    
    Image scaleByPercentage(String name, String imagePath, Double percentage) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        ImageProcessorService imageProcessorService = serviceAPI.buildImageProcessorService()
        Image image = imageProcessorService.scaleByPercentage(name, imagePath, percentage)
        return image
    }
    
    Image resize(String name, InputStream inputStream, Integer width, Integer height) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        ImageProcessorService imageProcessorService = serviceAPI.buildImageProcessorService()
        Image image = imageProcessorService.resize(name, inputStream, width, height)
        return image
    }
    
    Image thumbnail(String name, InputStream inputStream, Integer width, Integer height) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        ImageProcessorService imageProcessorService = serviceAPI.buildImageProcessorService()
        Image image = imageProcessorService.thumbnail(name, inputStream, width, height)
        return image
    }
    
    Image scale(String name, InputStream inputStream, Integer width, Integer height) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        ImageProcessorService imageProcessorService = serviceAPI.buildImageProcessorService()
        Image image = imageProcessorService.scale(name, inputStream, width, height)
        return image
    }
    
    Image crop(String name, InputStream inputStream, Integer width, Integer height, Integer x, Integer y) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        ImageProcessorService imageProcessorService = serviceAPI.buildImageProcessorService()
        Image image = imageProcessorService.crop(name, inputStream, width, height, x, y)
        return image
    }

    Image resizeByPercentage(String name, InputStream inputStream, Double percentage) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        ImageProcessorService imageProcessorService = serviceAPI.buildImageProcessorService()
        Image image = imageProcessorService.resizeByPercentage(name, inputStream, percentage)
        return image
    }
    
    Image thumbnailByPercentage(String name, InputStream inputStream, Double percentage) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        ImageProcessorService imageProcessorService = serviceAPI.buildImageProcessorService()
        Image image = imageProcessorService.thumbnailByPercentage(name, inputStream, percentage)
        return image
    }
    
    Image scaleByPercentage(String name, InputStream inputStream, Double percentage) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        ImageProcessorService imageProcessorService = serviceAPI.buildImageProcessorService()
        Image image = imageProcessorService.scaleByPercentage(name, inputStream, percentage)
        return image
    }
   Image convertFormat(String name, String imagePath, String formatToConvert) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        ImageProcessorService imageProcessorService = serviceAPI.buildImageProcessorService()
        Image image = imageProcessorService.convertFormat(name, imagePath, formatToConvert)
        return image
    }
    Image convertFormat(String name, InputStream inputStream, String formatToConvert) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        ImageProcessorService imageProcessorService = serviceAPI.buildImageProcessorService()
        Image image = imageProcessorService.convertFormat(name, inputStream, formatToConvert)
        return image
    }
}
