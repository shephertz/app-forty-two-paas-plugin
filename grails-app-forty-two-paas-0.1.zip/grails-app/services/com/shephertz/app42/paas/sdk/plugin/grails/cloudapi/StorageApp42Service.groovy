package com.shephertz.app42.paas.sdk.plugin.grails.cloudapi

import com.shephertz.app42.paas.sdk.java.ServiceAPI
import com.shephertz.app42.paas.sdk.java.storage.QueryBuilder
import com.shephertz.app42.paas.sdk.java.storage.Storage
import com.shephertz.app42.paas.sdk.java.storage.OrderByType
import com.shephertz.app42.paas.sdk.java.storage.Query
import com.shephertz.app42.paas.sdk.java.storage.StorageService
import com.shephertz.app42.paas.sdk.java.App42Exception
import com.shephertz.app42.paas.sdk.java.App42Response

class StorageApp42Service {

    static transactional = true
    static scope = "request"
    
    def apiService

    Storage insertJSONDocument(String dbName, String collectionName, String json) throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        StorageService storageService = serviceAPI.buildStorageService()
        Storage storage = storageService.insertJSONDocument(dbName,collectionName,json)
        return storage
    }
    
    Storage findAllDocuments(String dbName, String collectionName) throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        StorageService storageService = serviceAPI.buildStorageService()
        Storage storage = storageService.findAllDocuments(dbName,collectionName)
        return storage
    }
    
    App42Response findAllDocumentsCount(String dbName, String collectionName){
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        StorageService storageService = serviceAPI.buildStorageService()
        return storageService.findAllDocumentsCount(dbName, collectionName)
    }
			
    Storage findAllDocuments(String dbName, String collectionName,int max, int offset) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        StorageService storageService = serviceAPI.buildStorageService()
        Storage storage = storageService.findAllDocuments(dbName, collectionName, max, offset)
        return storage
    }
    
    
    Storage findDocumentById(String dbName, String collectionName, String docId) throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        StorageService storageService = serviceAPI.buildStorageService()
        Storage storage = storageService.findDocumentById(dbName,collectionName,docId)
        return storage
    }
    
    Storage findDocumentByKeyValue(String dbName, String collectionName, String key, String value) throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        StorageService storageService = serviceAPI.buildStorageService()
        Storage storage = storageService.findDocumentByKeyValue(dbName,collectionName,key,value)
        return storage
    }
    
    Storage updateDocumentByKeyValue(String dbName, String collectionName, String key, String value, String newJsonDoc) throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        StorageService storageService = serviceAPI.buildStorageService()
        Storage storage = storageService.updateDocumentByKeyValue(dbName,collectionName,key,value,newJsonDoc)
        return storage
    }
    
    App42Response deleteDocumentById(String dbName, String collectionName, String docId) throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        StorageService storageService = serviceAPI.buildStorageService()
        return storageService.deleteDocumentById(dbName, collectionName, docId)
    }
    
    String mapReduce(String dbName, String collectionName, String mapFunction, String reduceFunction) throws App42Exception{
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        StorageService storageService = serviceAPI.buildStorageService()
        return storageService.mapReduce(dbName, collectionName, mapFunction, reduceFunction)
    }
    
    Storage insertJsonDocUsingMap(String dbName, String collectionName,HashMap<String, String> map) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        StorageService storageService = serviceAPI.buildStorageService()
        Storage storage = storageService.insertJsonDocUsingMap(dbName, collectionName, map)
        return storage
    }
    Storage updateDocumentByDocId(String dbName, String collectionName,String docId, String newJsonDoc) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        StorageService storageService = serviceAPI.buildStorageService()
        Storage storage = storageService.updateDocumentByDocId(dbName, collectionName, docId, newJsonDoc)
        return storage
    }
    Storage findDocumentsByQuery(String dbName, String collectionName,Query query) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        StorageService storageService = serviceAPI.buildStorageService()
        Storage storage = storageService.findDocumentsByQuery(dbName, collectionName, query)
        return storage
    }
    Storage findDocumentsByQueryWithPaging(String dbName, String collectionName,Query query, int max, int offset) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        StorageService storageService = serviceAPI.buildStorageService()
        Storage storage = storageService.findDocumentsByQueryWithPaging(dbName, collectionName, query, max, offset)
        return storage
    }
    Storage findDocsWithQueryPagingOrderBy(String dbName, String collectionName,Query query, int max, int offset, String orderByKey, OrderByType type) throws App42Exception {
        ServiceAPI serviceAPI = apiService.getServiceAPI()
        StorageService storageService = serviceAPI.buildStorageService()
        Storage storage = storageService.findDocsWithQueryPagingOrderBy(dbName, collectionName, query, max, offset ,orderByKey ,type)
        return storage
    }
}
